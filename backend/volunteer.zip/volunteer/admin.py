from django.contrib import admin
from .models import Volunteer

admin.site.register(Volunteer)
